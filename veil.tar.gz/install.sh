#!/usr/bin/env bash
# Veil installer — https://github.com/GurovNA/Veil
# Usage: bash install.sh [--step N] [--dry-run] [--help]
set -euo pipefail

VERSION="2.4.4"
REPO="GurovNA/Veil"
LOG_FILE="/var/log/veil-install.log"
IPIFY="https://api.ipify.org"
TELEMT_PORT=7443
PANEL_PORT=8443
TLS_DOMAIN="www.microsoft.com"   # SNI-фронт MTProto: обязан отдавать TLS1.3+X25519MLKEM768 (iOS), my.aeza.ru — только TLS1.2

# ---------- language ----------
# RU by default; EN auto-detected from locale or forced with --lang en.
L_EN=0
case "${LANGUAGE:-${LANG:-}}" in en*) L_EN=1 ;; esac
T() { if [ "$L_EN" = "1" ]; then printf '%s' "$2"; else printf '%s' "$1"; fi; }

# ---------- colors ----------
if [ -t 1 ]; then
  C_R="\033[31m"; C_G="\033[32m"; C_Y="\033[33m"; C_B="\033[36m"; C_N="\033[0m"
else
  C_R=""; C_G=""; C_Y=""; C_B=""; C_N=""
fi

msg()   { printf "${C_B}[*]${C_N} %s\n" "$*" | tee -a "$LOG_FILE"; }
ok()    { printf "${C_G}[✓]${C_N} %s\n" "$*" | tee -a "$LOG_FILE"; }
warn()  { printf "${C_Y}[!]${C_N} %s\n" "$*" | tee -a "$LOG_FILE"; }
err()   { printf "${C_R}[✗]${C_N} %s\n" "$*" | tee -a "$LOG_FILE"; }
die()   { err "$*"; exit 1; }

# ---------- cli ----------
DRY_RUN=0
ONLY_STEP=""

usage() {
  cat <<EOF
Veil installer v$VERSION

Usage:
  bash install.sh                $(T "Интерактивное меню управления" "Interactive manage menu")
  bash install.sh --step N       $(T "Выполнить только шаг N" "Run only step N")
  bash install.sh --dry-run      $(T "Показать команды, не выполнять" "Show commands without running")
  bash install.sh --lang ru|en   $(T "Язык сообщений (по умолчанию — по локали)" "Message language (default: from locale)")
  bash install.sh --help         $(T "Это сообщение" "This message")
EOF
}

run() {
  if [ "$DRY_RUN" = "1" ]; then
    printf "${C_Y}[dry]${C_N} %s\n" "$*"
    return 0
  fi
  eval "$@" >>"$LOG_FILE" 2>&1
}

find_free_port() {
  FP_MSG="$(T "нет свободного порта рядом с" "no free port near")" python3 - "$1" <<'PYFP'
import os, socket, sys
start = int(sys.argv[1])
for p in range(start, start + 50):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("", p)); s.close()
        print(p); sys.exit(0)
    except OSError:
        s.close()
print(os.environ["FP_MSG"] + " " + str(start), file=sys.stderr)
sys.exit(1)
PYFP
}

# ---------- целостность релизного архива ----------
# Релиз несёт veil.tar.gz.sha256 рядом с veil.tar.gz. Скачанный архив сверяется
# по ней ДО распаковки: несовпадение останавливает установку, а отсутствие
# свери — не повод ставить непроверенное, тогда остаётся путь локальных файлов.
# Доверие здесь то же, что у самой загрузки: сверь ловит подмену зеркала и
# битую передачу, но не взломанный аккаунт, выложивший и архив и дайджест.
verify_release_tarball() {
  # 0 — совпало, 1 — не совпало, 2 — сверить нечем.
  local url="$1" file="$2" want got cand
  rm -f "$file.digest"
  for cand in "${url}.sha256" "${url%.tar.gz}.sha256"; do
    if curl -fsSL --max-time 20 -o "$file.digest" "$cand" 2>/dev/null; then
      break
    fi
    rm -f "$file.digest"
  done
  if [ ! -s "$file.digest" ]; then
    rm -f "$file.digest"
    return 2
  fi
  want="$(awk 'NR==1 {print tolower($1)}' "$file.digest" 2>/dev/null)"
  rm -f "$file.digest"
  case "$want" in
    "") return 2 ;;
    *[!0-9a-f]*) return 2 ;;
  esac
  if [ "${#want}" -ne 64 ]; then return 2; fi
  if command -v sha256sum >/dev/null 2>&1; then
    got="$(sha256sum "$file" 2>/dev/null | cut -d' ' -f1)"
  elif command -v openssl >/dev/null 2>&1; then
    got="$(openssl dgst -sha256 -r "$file" 2>/dev/null | cut -d' ' -f1)"
  else
    return 2
  fi
  if [ -z "$got" ]; then return 2; fi
  if [ "$want" = "$got" ]; then return 0; fi
  return 1
}

step_0_preflight() {
  msg "$(T "Шаг 0: проверка перед установкой" "Step 0: pre-flight checks")"
  [ "$(id -u)" = "0" ] || die "$(T "нужен запуск от root" "must run as root")"
  ok "root"
  # os-release задаёт собственную VERSION/ID и т.п. — читаем в подоболочке,
  # чтобы не перезатереть наш VERSION="..." (иначе меню и лог врют про версию).
  (. /etc/os-release) 2>/dev/null || true
  SERVER_IP="$(curl -fsSL --max-time 8 "$IPIFY" 2>/dev/null || true)"
  [ -n "$SERVER_IP" ] || die "$(T "не удалось определить внешний IP — проверь сеть" "could not detect public IP — check network")"
  ok "$(T "внешний IP" "public IP"): $SERVER_IP"
  [ -d /etc/systemd/system ] || die "$(T "/etc/systemd/system не найден" "/etc/systemd/system not found")"
  ok "$(T "systemd на месте" "systemd present")"
}

step_1_packages() {
  msg "$(T "Шаг 1: пакеты apt" "Step 1: apt packages")"
  export DEBIAN_FRONTEND=noninteractive
  run "apt-get update -y"
  # Реестр #288 пункт 1: certbot не входил в список — на чистой ОС выпуск сертификата
  # тонул в невнятном отказе установщика; теперь пакет просим сразу.
  PKGS="python3 curl openssl tar jq nftables qrencode ca-certificates unzip wireguard-tools certbot"
  run "apt-get install -y $PKGS"
  msg "$(T "Примечание: AmneziaWG в штатных репозиториях нет — он ставится отдельно (модуль ядра + awg-quick из исходников Amnezia); без него панель честно откажет по этой группе." "Note: AmneziaWG is not in stock repos — install it separately (kernel module + awg-quick from Amnezia sources); without it the panel will honestly refuse that group.")"
  command -v python3 >/dev/null || die "$(T "python3 не поставился" "python3 failed to install")"
  command -v nft     >/dev/null || die "$(T "nftables не поставился" "nftables failed to install")"
  command -v curl    >/dev/null || die "$(T "curl не поставился" "curl failed to install")"
  ok "$(T "пакеты установлены" "packages installed")"
}

step_2_xray() {
  msg "$(T "Шаг 2: Xray (VLESS + Reality)" "Step 2: Xray (VLESS + Reality)")"
  if [ -x /usr/local/bin/xray ]; then
    ok "$(T "Xray уже установлен" "Xray already installed"): $(/usr/local/bin/xray version 2>/dev/null | head -1)"
  else
    run "curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh -o /tmp/xray-install.sh"
    run "bash /tmp/xray-install.sh install"
  fi

  cat <<'UNITEOF' > /etc/systemd/system/xray.service
[Unit]
Description=Xray Service
Documentation=https://github.com/xtls
After=network.target nss-lookup.target

[Service]
User=root
# CAP_DAC_OVERRIDE — панель отдаёт ключи/серты (hy2_key.pem и др.) с владельцем
# nobody:0600; без этой capability root-xray не может их прочитать и падает в
# crash-loop на чистом хосте (проверено на VPS).
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_DAC_OVERRIDE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_DAC_OVERRIDE
NoNewPrivileges=true
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
RestartSec=3
DynamicUser=false
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  [ -x /usr/local/bin/xray ] || die "$(T "Xray не установился" "Xray failed to install")"
  if [ ! -f /usr/local/etc/xray/config.json ]; then
    run "mkdir -p /usr/local/etc/xray"
    run "echo '{\"log\":{\"loglevel\":\"warning\"},\"inbounds\":[],\"outbounds\":[{\"protocol\":\"freedom\"}]}' > /usr/local/etc/xray/config.json"
  fi
  # F8 (#466): голый `enable` поднимал xray только после перезагрузки — при
  # переустановке на грязном хосте все туннели оставались мёртвыми.
  if [ "$DRY_RUN" = 1 ] || systemctl enable --now xray >>"$LOG_FILE" 2>&1; then
    ok "$(T "Xray service настроен" "Xray service configured")"
  else
    warn "$(T "xray не стартовал сейчас — панель поднимет его после первого применения конфига" "xray did not start now — the panel will bring it up after the first config apply")"
  fi
}

step_3_telemt() {
  msg "$(T "Шаг 3: telemt (Telegram MTProto)" "Step 3: telemt (Telegram MTProto)")"
  # F9 (#466): раньше шаг выходил по одному лишь наличию бинарника — переустановка
  # на грязном хосте оставляла telemt выключенным. «уже есть» теперь лишь пропускает
  # скачивание: юнит, права и enabled+active доводятся на всех путях.
  if [ -x /usr/bin/telemt ]; then
    ok "$(T "telemt уже установлен" "telemt already installed")"
  else
    if [ ! -f /etc/telemt/telemt.toml ]; then
      TELEMT_PORT="$(find_free_port "$TELEMT_PORT")"
    fi
    local arch variant asset_name tag url
    case "$(uname -m)" in
      x86_64)  arch="x86_64" ;;
      aarch64) arch="aarch64" ;;
      *) die "$(T "неподдерживаемая архитектура" "unsupported architecture"): $(uname -m)" ;;
    esac
    variant=""
    if [ "$arch" = "x86_64" ] && grep -qm1 avx2 /proc/cpuinfo 2>/dev/null; then
      variant="v3"
    fi
    asset_name="telemt-${arch}${variant:+-${variant}}-linux-gnu.tar.gz"
    tag="$(curl -fsSL https://api.github.com/repos/telemt/telemt/releases/latest 2>/dev/null \
      | python3 -c 'import sys,json; print(json.load(sys.stdin)["tag_name"])' 2>/dev/null || true)"
    [ -n "$tag" ] || tag="v1.0.0"
    url="https://github.com/telemt/telemt/releases/download/${tag}/${asset_name}"
    run "curl -fsSL -o /tmp/telemt.tar.gz '$url' || curl -fsSL -o /tmp/telemt.tar.gz 'https://github.com/telemt/telemt/releases/latest/download/telemt-${arch}-linux-gnu.tar.gz'"
    run "tar -xzf /tmp/telemt.tar.gz -C /tmp 2>/dev/null || true"
    run "install -m 0755 /tmp/telemt /usr/bin/telemt 2>/dev/null || true"
    run "rm -f /tmp/telemt.tar.gz /tmp/telemt"
  fi
  if ! id telemt >/dev/null 2>&1; then
    run "useradd -r -s /usr/sbin/nologin -M telemt"
  fi
  run "mkdir -p /opt/telemt /etc/telemt /var/lib/telemt"
  # F1 (#466): каталог /etc/telemt тоже telemt:telemt — раньше доставался только
  # файл конфига, а при готовом чужом конфиге (root:root 0600) демон не мог его
  # прочесть и крушился; права доводятся безусловно, вне зависимости от того,
  # создавался конфиг сейчас или лежал заранее.
  run "chown telemt:telemt /opt/telemt /etc/telemt /var/lib/telemt"
  if [ ! -f /etc/telemt/telemt.toml ]; then
    local secret v6
    secret="$(openssl rand -hex 16)"
    # F6 (#466): `ipv6 = true` без v6-маршрута роняет telemt в crash-loop на
    # v4-only хосте — пишем true только при живом маршруте наружу.
    if ip -6 route get 2001:4860:4860::8888 >/dev/null 2>&1; then v6=true; else v6=false; fi
    cat <<TOMLEOF > /etc/telemt/telemt.toml
[general]
use_middle_proxy = true
tg_connect = 30
[general.modes]
classic = false
secure = false
tls = true
[network]
ipv6 = ${v6}
[server]
port = ${TELEMT_PORT}
[server.api]
enabled = true
listen = "127.0.0.1:9091"
whitelist = ["127.0.0.1/32"]
[censorship]
tls_domain = "${TLS_DOMAIN}"
[access.users]
hello = "${secret}"
[timeouts]
client_handshake = 90
client_keepalive = 120
TOMLEOF
  fi
  chmod 0640 /etc/telemt/telemt.toml
  chown telemt:telemt /etc/telemt/telemt.toml
  if [ ! -f /etc/systemd/system/telemt.service ]; then
    cat <<'UNITEOF' > /etc/systemd/system/telemt.service
[Unit]
Description=Telemt
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=telemt
Group=telemt
WorkingDirectory=/opt/telemt
ExecStart=/usr/bin/telemt /etc/telemt/telemt.toml
Restart=on-failure
RestartSec=5
LimitNOFILE=65536
AmbientCapabilities=CAP_NET_BIND_SERVICE CAP_NET_ADMIN
CapabilityBoundingSet=CAP_NET_BIND_SERVICE CAP_NET_ADMIN
[Install]
WantedBy=multi-user.target
UNITEOF
  fi
  run "systemctl daemon-reload"
  run "systemctl enable --now telemt"
  ok "$(T "telemt готов" "telemt ready")"
}

step_4_zapret2() {
  msg "$(T "Шаг 4: veil-zapret2 (DPI bypass)" "Step 4: veil-zapret2 (DPI bypass)")"
  if [ -x /opt/veil-zapret2/bin/nfqws2 ]; then
    ok "$(T "veil-zapret2 уже установлен" "veil-zapret2 already installed")"
    run "systemctl enable --now veil-zapret2"
    return 0
  fi
  local ZV="v1.0.3"
  local ZURL="https://github.com/bol-van/zapret2/releases/download/${ZV}/zapret2-${ZV}.tar.gz"
  run "mkdir -p /opt/veil-zapret2/bin /opt/veil-zapret2/lua /etc/veil-zapret2"
  run "curl -fsSL -o /tmp/zapret2.tar.gz '$ZURL' || true"
  run "tar -xzf /tmp/zapret2.tar.gz -C /tmp --strip-components=1 2>/dev/null || true"
  if [ -f /tmp/binaries/linux-x86_64/nfqws2 ]; then
    install -m 0755 /tmp/binaries/linux-x86_64/nfqws2 /opt/veil-zapret2/bin/nfqws2 || true
  fi
  cat <<'LUA_VEIL_EOF' > /opt/veil-zapret2/lua/veil-mtproto.lua
function lets_resend(ctx, desync)
    return VERDICT_PASS
end
LUA_VEIL_EOF
  cat <<CONFEOF > /etc/veil-zapret2/mtproto.conf
--qnum 201 --fwmark=0x40000000 --server --uid=65534:65534 --filter-tcp=${TELEMT_PORT}
CONFEOF
  cat <<'STARTEOF' > /usr/local/sbin/veil-zapret2-start.sh
#!/bin/bash
exec /opt/veil-zapret2/bin/nfqws2 @/etc/veil-zapret2/mtproto.conf 2>/dev/null || true
STARTEOF
  chmod 0755 /usr/local/sbin/veil-zapret2-start.sh
  cat <<'UNITEOF' > /etc/systemd/system/veil-zapret2.service
[Unit]
Description=Veil Zapret2 MTProto fix
After=network-online.target
[Service]
Type=simple
ExecStart=/usr/local/sbin/veil-zapret2-start.sh
Restart=on-failure
[Install]
WantedBy=multi-user.target
UNITEOF
  run "systemctl daemon-reload"
  run "systemctl enable --now veil-zapret2 || true"
  ok "$(T "veil-zapret2 готов" "veil-zapret2 ready")"
}

step_5_panel() {
  msg "$(T "Шаг 5" "Step 5"): $(T "панель Veil" "Veil panel") v$VERSION"
  local TARBALL_URL="https://github.com/${REPO}/releases/latest/download/veil.tar.gz"
  if [ "$DRY_RUN" = "1" ]; then
    # Не трогаем диск: только показываем, что будет сделано.
    printf "${C_Y}[dry]${C_N} mkdir -p /opt/vpnpanel\n"
    printf "${C_Y}[dry]${C_N} curl -fsSL -o /tmp/veil.tar.gz '%s' && tar -xzf /tmp/veil.tar.gz -C /opt/vpnpanel\n" "$TARBALL_URL"
    printf "${C_Y}[dry]${C_N} curl -fsSL -o /tmp/veil.tar.gz.sha256 '%s' && sha256sum -c /tmp/veil.tar.gz.sha256\n" "${TARBALL_URL}.sha256"
    if [ ! -f /opt/vpnpanel/config.json ]; then
      printf "${C_Y}[dry]${C_N} $(T "сгенерировать /opt/vpnpanel/config.json и FIRST-LOGIN.txt (порт из find_free_port %s)" "generate /opt/vpnpanel/config.json and FIRST-LOGIN.txt (port from find_free_port %s)")\n" "$PANEL_PORT"
    fi
    printf "${C_Y}[dry]${C_N} $(T "записать /etc/systemd/system/vpnpanel.service" "write /etc/systemd/system/vpnpanel.service")\n"
    run "systemctl daemon-reload"
    run "systemctl enable --now vpnpanel"
    ok "$(T "панель активна (dry-run)" "panel active (dry-run)")"
    return 0
  fi
  if [ ! -f /opt/vpnpanel/config.json ]; then
    PANEL_PORT="$(find_free_port "$PANEL_PORT")"
  fi
  run "mkdir -p /opt/vpnpanel"
  if curl -fsSL -o /tmp/veil.tar.gz "$TARBALL_URL" 2>/dev/null; then
    VRC=0
    verify_release_tarball "$TARBALL_URL" /tmp/veil.tar.gz || VRC=$?
    if [ "$VRC" = "0" ]; then
      ok "$(T "Контрольная сумма релизного архива совпала" "Release archive checksum verified")"
      tar -xzf /tmp/veil.tar.gz -C /opt/vpnpanel 2>/dev/null || true
      rm -f /tmp/veil.tar.gz
    elif [ "$VRC" = "1" ]; then
      rm -f /tmp/veil.tar.gz
      die "$(T "Контрольная сумма релизного архива НЕ совпала — установка остановлена" "Release archive checksum MISMATCH — installation halted")"
    else
      rm -f /tmp/veil.tar.gz
      warn "$(T "Контрольную сумму получить не удалось — архив НЕ распакован" "Checksum unavailable — archive NOT extracted")"
    fi
  else
    warn "$(T "Не удалось скачать релиз с GitHub, используем локальные файлы" "Failed to download release from GitHub, using local files")"
  fi
  if [ ! -f /opt/vpnpanel/config.json ]; then
    python3 - "$PANEL_PORT" <<'PYCFG'
import json, hashlib, os, secrets, sys
CFG = "/opt/vpnpanel/config.json"
LOG = "/opt/vpnpanel/FIRST-LOGIN.txt"
panel_port = int(sys.argv[1])
login = (os.environ.get("VEIL_PANEL_LOGIN") or "").strip() or "admin"
salt  = secrets.token_hex(16)
pw    = secrets.token_urlsafe(12)
h     = "pbkdf2_sha256$300000$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 300000).hex()
cfg = {"login": login, "salt": salt, "pass_hash": h, "panel_port": panel_port}
# VEIL_DOMAIN и VEIL_EMAIL — необязательные подсказки оператора: домен панели и почта
# для выпуска сертификата. Секретов здесь нет и быть не должно: токены dns и пароли
# панель берёт из своих полей настроек, а не из окружения.
dom = (os.environ.get("VEIL_DOMAIN") or "").strip().lower().strip(".")
if dom and "." in dom:
    cfg["panel_domain"] = dom
mail = (os.environ.get("VEIL_EMAIL") or "").strip()
if "@" in mail:
    cfg["cert_email"] = mail
with open(CFG, "w") as f:
    json.dump(cfg, f, indent=2)
os.chmod(CFG, 0o600)
with open(LOG, "w") as f:
    f.write(f"login:    {login}\npassword: {pw}\n")
os.chmod(LOG, 0o600)
PYCFG
  fi
  cat <<'UNITEOF' > /etc/systemd/system/vpnpanel.service
[Unit]
Description=VPN Panel
After=network-online.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/vpnpanel/panel.py
Restart=always
RestartSec=2
LimitNOFILE=65535
[Install]
WantedBy=multi-user.target
UNITEOF
  run "systemctl daemon-reload"
  run "systemctl enable --now vpnpanel"
  ok "$(T "панель активна" "panel active")"
}

step_6_finish() {
  msg "$(T "Шаг 6: итог" "Step 6: summary")"
  show_panel_info_internal
}

show_panel_info_internal() {
  local ip _d
  ip="${SERVER_IP:-$(curl -fsSL --max-time 5 "$IPIFY" 2>/dev/null || echo 'SERVER_IP')}"
  
  if [ -f /opt/vpnpanel/config.json ]; then
    _p="$(python3 -c 'import json;print(json.load(open("/opt/vpnpanel/config.json")).get("panel_port",8443))' 2>/dev/null)"
    [ -n "$_p" ] && PANEL_PORT="$_p"
  fi

  # Показываем РЕАЛЬную версию установленной панели, а не версию установщика:
  # установщик (VERSION выше) может отставать, и обычный человек путается,
  # когда карточка «Veil vX» не совпадает с версией в шапке самой панели.
  local _pv="$VERSION"
  if [ -f /opt/vpnpanel/panel.py ]; then
    _f="$(grep -m1 -oE '^VERSION[[:space:]]*=[[:space:]]*"[^"]+"' /opt/vpnpanel/panel.py | sed -E 's/.*"([^"]+)".*/\1/' 2>/dev/null)"
    [ -n "$_f" ] && _pv="$_f"
  fi

  echo
  echo -e "${C_B}================================================================${C_N}"
  echo -e "${C_B}  Veil v${_pv} - $(T "информация о панели" "panel information")${C_N}"
  echo -e "${C_B}================================================================${C_N}"
  echo -e "  $(T "Адрес панели (URL)" "Panel URL"):  ${C_B}http://${ip}:${PANEL_PORT}${C_N}"
  _d="$(python3 -c 'import json;print(json.load(open("/opt/vpnpanel/config.json")).get("panel_domain",""))' 2>/dev/null)"
  if [ -n "$_d" ]; then
    echo -e "  $(T "Домен (из VEIL_DOMAIN)" "Domain (from VEIL_DOMAIN)"):  ${C_G}${_d}${C_N}"
  fi
  echo -e "  $(T "Дальше: откройте панель и нажмите «⚡ Автонастройку» — она выпустит поддомены, сертификат и переведёт входы на порт 443" "Next: open the panel and press Auto-setup — it issues subdomains, a certificate and moves entries to port 443")"
  echo
  if [ -f /opt/vpnpanel/FIRST-LOGIN.txt ]; then
    local _L _P
    _L="$(awk '/^login:/    {print $2}' /opt/vpnpanel/FIRST-LOGIN.txt)"
    _P="$(awk '/^password:/ {print $2}' /opt/vpnpanel/FIRST-LOGIN.txt)"
    echo -e "  $(T "Логин" "Login"):  ${C_G}${_L}${C_N}"
    echo -e "  $(T "Пароль" "Password"): ${C_G}${_P}${C_N}"
    echo -e "  $(T "первоначальный пароль из FIRST-LOGIN.txt" "initial password from FIRST-LOGIN.txt")"
  else
    echo -e "  $(T "Логин" "Login"):  ${C_G}admin${C_N}"
    echo -e "  $(T "Пароль" "Password"): $(T "используйте ваш текущий пароль от панели" "use your current panel password")"
  fi
  echo -e "${C_B}================================================================${C_N}"
  echo
}

show_panel_info() {
  show_panel_info_internal
  exit 0
}

run_install_steps() {
  for s in 0 1 2 3 4 5 6; do
    if [ -n "$ONLY_STEP" ] && [ "$ONLY_STEP" != "$s" ]; then
      continue
    fi
    "step_${s}_"$( case $s in
      0) echo preflight ;;
      1) echo packages ;;
      2) echo xray ;;
      3) echo telemt ;;
      4) echo zapret2 ;;
      5) echo panel ;;
      6) echo finish ;;
    esac )
  done
}

uninstall_completely() {
  msg "$(T "Удаление Veil и всех компонентов..." "Removing Veil and all components...")"
  systemctl stop vpnpanel xray telemt veil-zapret2 nginx 2>/dev/null || true
  systemctl disable vpnpanel xray telemt veil-zapret2 nginx 2>/dev/null || true
  rm -f /etc/systemd/system/vpnpanel.service
  rm -f /etc/systemd/system/telemt.service
  rm -f /etc/systemd/system/veil-zapret2.service
  rm -f /etc/systemd/system/xray.service
  systemctl daemon-reload
  rm -rf /opt/vpnpanel /opt/telemt /etc/telemt /var/lib/telemt /opt/veil-zapret2 /etc/veil-zapret2 /usr/local/etc/xray
  nft delete table ip veil_mtproto 2>/dev/null || true
  ok "$(T "Veil полностью удален с сервера." "Veil has been fully removed from the server.")"
  exit 0
}

reinstall_keeping_data() {
  msg "$(T "Переустановка с сохранением данных..." "Reinstalling while keeping data...")"
  local TARBALL_URL="https://github.com/${REPO}/releases/latest/download/veil.tar.gz"
  mkdir -p /opt/vpnpanel
  if curl -fsSL -o /tmp/veil.tar.gz "$TARBALL_URL" 2>/dev/null; then
    VRC=0
    verify_release_tarball "$TARBALL_URL" /tmp/veil.tar.gz || VRC=$?
    if [ "$VRC" = "0" ]; then
      tar -xzf /tmp/veil.tar.gz -C /opt/vpnpanel 2>/dev/null || true
      rm -f /tmp/veil.tar.gz
      ok "$(T "Панель обновлена из релиза, контрольная сумма совпала" "Panel updated from release, checksum verified") v$VERSION"
    elif [ "$VRC" = "1" ]; then
      rm -f /tmp/veil.tar.gz
      die "$(T "Контрольная сумма релизного архива НЕ совпала — обновление остановлено" "Release archive checksum MISMATCH — update halted")"
    else
      rm -f /tmp/veil.tar.gz
      warn "$(T "Контрольную сумму получить не удалось — архив НЕ распакован" "Checksum unavailable — archive NOT extracted")"
    fi
  else
    warn "$(T "Не удалось скачать релиз с GitHub, используем текущие файлы" "Failed to download release from GitHub, using current files")"
  fi

  # Восстанавливаем/проверяем systemd-юнит панели
  cat <<'UNITEOF' > /etc/systemd/system/vpnpanel.service
[Unit]
Description=VPN Panel
After=network-online.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/vpnpanel/panel.py
Restart=always
RestartSec=2
LimitNOFILE=65535
[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  systemctl enable --now vpnpanel
  systemctl restart vpnpanel
  # telemt кэширует каталог заглушки (/opt/vpnpanel/decoy) при старте:
  # без перезапуска посетители продолжают видеть старый index.html и не видят новые .nes.
  systemctl is-active --quiet telemt && systemctl restart telemt
  ok "$(T "Переустановка с сохранением данных завершена." "Reinstall keeping data completed.")"
  show_panel_info_internal
  exit 0
}

reinstall_deleting_data() {
  warn "$(T "Внимание: все данные будут удалены!" "Warning: all data will be deleted!")"
  read -rp "$(T "Продолжить? [y/N]: " "Continue? [y/N]: ")" confirm
  if [[ "$confirm" =~ ^[Yy]$ ]]; then
    systemctl stop vpnpanel xray telemt veil-zapret2 2>/dev/null || true
    rm -rf /opt/vpnpanel
    run_install_steps
  else
    msg "$(T "Отменено." "Cancelled.")"
    exit 0
  fi
}

main() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --dry-run) DRY_RUN=1 ;;
      --step)    ONLY_STEP="${2:-}"; shift ;;
      --lang)    case "${2:-}" in
                   en|en_US|en-US|english) L_EN=1 ;;
                   ru|ru_RU|ru-RU) L_EN=0 ;;
                   *) die "$(T "неизвестный язык: " "unknown language: ")${2:-}" ;;
                 esac; shift ;;
      --lang=*)  case "${1#--lang=}" in
                   en|en_US|en-US|english) L_EN=1 ;;
                   ru|ru_RU|ru-RU) L_EN=0 ;;
                   *) die "$(T "неизвестный язык: " "unknown language: ")${1#--lang=}" ;;
                 esac ;;
      --help|-h) usage; exit 0 ;;
      *) die "$(T "неизвестный аргумент: " "unknown argument: ")$1" ;;
    esac
    shift
  done

  [ -w /var/log ] || LOG_FILE="/tmp/veil-install.log"
  : >"$LOG_FILE"

  if [ -n "$ONLY_STEP" ]; then
    run_install_steps
    exit 0
  fi

  # Интерактивное меню управления
  echo -e "${C_B}================================================================${C_N}"
  echo -e "${C_B}            Veil Installer & Manager v$VERSION                  ${C_N}"
  echo -e "${C_B}================================================================${C_N}"
  echo -e "  1) $(T "Установить" "Install")"
  echo -e "  2) $(T "Переустановить с сохранением данных" "Reinstall keeping data")"
  echo -e "  3) $(T "Переустановить с удалением данных" "Reinstall deleting data")"
  echo -e "  4) $(T "Удалить полностью панель" "Uninstall panel completely")"
  echo -e "  5) $(T "Показать адрес панели" "Show panel URL")"
  echo -e "  0) $(T "Выход" "Exit")"
  echo -e "${C_B}================================================================${C_N}"
  read -rp "$(T "Выберите пункт [1-5]: " "Choose item [1-5]: ")" choice

  case "$choice" in
    1) run_install_steps ;;
    2) reinstall_keeping_data ;;
    3) reinstall_deleting_data ;;
    4) uninstall_completely ;;
    5) show_panel_info ;;
    0) exit 0 ;;
    *) err "$(T "Неверный выбор" "Invalid choice")"; exit 1 ;;
  esac

  ok "$(T "Готово" "Done")"
}

main "$@"
